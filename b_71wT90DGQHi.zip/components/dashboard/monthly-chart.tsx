"use client"

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
} from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronDown, Users, UserX } from "lucide-react"

const chartData = [
  { date: "1 Mei", hadir: 85, alpha: 15 },
  { date: "8 Mei", hadir: 88, alpha: 12 },
  { date: "15 Mei", hadir: 82, alpha: 18 },
  { date: "22 Mei", hadir: 90, alpha: 10 },
  { date: "27 Mei", hadir: 87, alpha: 13 },
]

export function MonthlyChart() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg">Grafik Presensi Bulan Ini</CardTitle>
        <button className="flex items-center gap-1 rounded-lg border px-3 py-1.5 text-sm">
          Mei 2025
          <ChevronDown className="h-4 w-4" />
        </button>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-emerald-500" />
            <span className="text-sm text-muted-foreground">Hadir (%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-red-500" />
            <span className="text-sm text-muted-foreground">Alpha (%)</span>
          </div>
        </div>

        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis
              dataKey="date"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: "#6b7280" }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: "#6b7280" }}
              domain={[0, 100]}
              ticks={[0, 25, 50, 75, 100]}
              tickFormatter={(value) => `${value}%`}
            />
            <Tooltip />
            <Line
              type="monotone"
              dataKey="hadir"
              stroke="#16a34a"
              strokeWidth={2}
              dot={{ fill: "#16a34a", strokeWidth: 2, r: 4 }}
            />
            <Line
              type="monotone"
              dataKey="alpha"
              stroke="#dc2626"
              strokeWidth={2}
              dot={{ fill: "#dc2626", strokeWidth: 2, r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span className="text-sm">Rata-rata Kehadiran</span>
            </div>
            <p className="mt-1 text-xl font-bold text-emerald-600">87.45%</p>
          </div>
          <div className="rounded-lg bg-muted/50 p-3 text-center">
            <div className="flex items-center justify-center gap-2 text-muted-foreground">
              <UserX className="h-4 w-4" />
              <span className="text-sm">Rata-rata Alpha</span>
            </div>
            <p className="mt-1 text-xl font-bold text-red-600">12.14%</p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
