"use client"

import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle } from "lucide-react"

const data = [
  { name: "Hadir", value: 111, color: "#16a34a", percentage: "79.29%" },
  { name: "Izin", value: 12, color: "#eab308", percentage: "8.57%" },
  { name: "Alpha", value: 17, color: "#dc2626", percentage: "12.14%" },
]

export function AttendanceDonut() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Ringkasan Presensi Hari Ini</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-8">
          <div className="relative">
            <ResponsiveContainer width={200} height={200}>
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-bold text-emerald-600">140</span>
              <span className="text-sm text-muted-foreground">Total Siswa</span>
            </div>
          </div>
          
          <div className="space-y-3">
            {data.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div
                  className="h-3 w-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                />
                <span className="text-sm font-medium">{item.name}</span>
                <span className="text-sm text-muted-foreground">
                  {item.value} ({item.percentage})
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between rounded-lg bg-muted/50 p-3">
          <div>
            <p className="text-sm text-muted-foreground">Presentase kehadiran hari ini</p>
            <p className="text-xl font-bold text-primary">79.29%</p>
          </div>
          <div className="flex items-center gap-1 text-emerald-600">
            <CheckCircle className="h-5 w-5" />
            <span className="font-medium">Baik</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
