"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, CheckCircle, MessageCircle, FileText } from "lucide-react"

const announcements = [
  {
    icon: CheckCircle,
    iconBg: "bg-emerald-100",
    iconColor: "text-emerald-600",
    title: "Pastikan presensi dilakukan setiap hari sebelum pukul 08:00 WIB.",
    date: "27 Mei 2025 - 08:30",
  },
  {
    icon: MessageCircle,
    iconBg: "bg-blue-100",
    iconColor: "text-blue-600",
    title: "Hubungi wali kelas jika ada ketidaksesuaian data presensi.",
    date: "26 Mei 2025 - 10:15",
  },
  {
    icon: FileText,
    iconBg: "bg-amber-100",
    iconColor: "text-amber-600",
    title: "Rekap presensi bulanan telah tersedia di menu Laporan.",
    date: "25 Mei 2025 - 09:00",
  },
]

export function Announcements() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Informasi & Pengumuman</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {announcements.map((item, index) => (
            <div key={index} className="flex gap-3">
              <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${item.iconBg}`}>
                <item.icon className={`h-5 w-5 ${item.iconColor}`} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium leading-tight">{item.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">{item.date}</p>
              </div>
            </div>
          ))}
        </div>

        <button className="mt-4 flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          Lihat Semua Pengumuman
          <ArrowRight className="h-4 w-4" />
        </button>
      </CardContent>
    </Card>
  )
}
