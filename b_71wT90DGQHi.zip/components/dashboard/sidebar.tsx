"use client"

import {
  LayoutDashboard,
  ClipboardList,
  FileEdit,
  FileBarChart,
  Users,
  School,
  FileText,
  UserX,
  Bell,
  Settings,
  ChevronDown,
} from "lucide-react"
import { cn } from "@/lib/utils"

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", active: true },
  { icon: ClipboardList, label: "Presensi Harian" },
  { icon: FileEdit, label: "Presensi Manual" },
  { icon: FileBarChart, label: "Rekap Presensi", hasDropdown: true },
  { icon: Users, label: "Data Siswa" },
  { icon: School, label: "Data Kelas" },
  { icon: FileText, label: "Laporan", hasDropdown: true },
  { icon: UserX, label: "Izin / Alpha" },
  { icon: Bell, label: "Pengumuman" },
  { icon: Settings, label: "Pengaturan", hasDropdown: true },
]

export function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 z-40 flex h-screen w-64 flex-col bg-sidebar text-sidebar-foreground">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-sidebar-border p-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/20">
          <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
            <span className="text-2xl">🏫</span>
          </div>
        </div>
        <div>
          <h1 className="font-bold text-lg">MIN 4 Pacitan</h1>
          <p className="text-sm text-sidebar-foreground/80">Sistem Presensi Siswa</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1 px-3">
          {menuItems.map((item) => (
            <li key={item.label}>
              <button
                className={cn(
                  "flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  item.active
                    ? "bg-amber-500 text-white"
                    : "text-sidebar-foreground/90 hover:bg-sidebar-accent"
                )}
              >
                <span className="flex items-center gap-3">
                  <item.icon className="h-5 w-5" />
                  {item.label}
                </span>
                {item.hasDropdown && <ChevronDown className="h-4 w-4" />}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      {/* School Info */}
      <div className="relative mt-auto">
        <div className="absolute bottom-0 left-0 right-0 h-40 overflow-hidden">
          <svg
            viewBox="0 0 400 160"
            className="absolute bottom-0 w-full h-full"
            preserveAspectRatio="xMidYMax slice"
          >
            <path
              d="M0,160 L0,80 Q50,60 100,75 Q150,90 200,70 Q250,50 300,65 Q350,80 400,60 L400,160 Z"
              fill="rgba(0,0,0,0.15)"
            />
          </svg>
          <div className="absolute bottom-8 left-4 text-white/90">
            <svg className="w-32 h-20" viewBox="0 0 120 80">
              <path d="M10,70 L25,50 L30,55 L40,40 L50,55 L60,35 L70,50 L75,45 L85,55 L90,50 L100,60 L100,70 Z" fill="rgba(255,255,255,0.3)" />
              <rect x="45" y="45" width="15" height="25" fill="rgba(255,255,255,0.4)" />
              <polygon points="52.5,35 40,50 65,50" fill="rgba(255,255,255,0.4)" />
              <circle cx="70" cy="40" r="3" fill="rgba(255,255,255,0.5)" />
            </svg>
          </div>
        </div>
        <div className="relative z-10 p-4">
          <div className="rounded-lg bg-white/10 p-3 backdrop-blur-sm">
            <p className="text-xs text-sidebar-foreground/70">Informasi Sekolah</p>
            <h3 className="font-semibold mt-1">MIN 4 Pacitan</h3>
            <p className="text-xs text-sidebar-foreground/80">NSM: 111235040004</p>
            <div className="mt-2">
              <p className="text-xs text-sidebar-foreground/70">Jumlah Siswa</p>
              <p className="text-2xl font-bold">140 <span className="text-sm font-normal">siswa</span></p>
            </div>
            <div className="mt-2">
              <p className="text-xs text-sidebar-foreground/70">Tahun Ajaran</p>
              <p className="text-sm font-medium">2024/2025 Genap</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  )
}
