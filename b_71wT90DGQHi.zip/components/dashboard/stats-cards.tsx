"use client"

import { Users, CheckCircle, Clock, XCircle } from "lucide-react"
import { Card } from "@/components/ui/card"

const stats = [
  {
    icon: Users,
    label: "Total Siswa",
    value: "140",
    subtitle: "7 Kelas",
    bgColor: "bg-emerald-50",
    iconBg: "bg-emerald-100",
    iconColor: "text-emerald-600",
  },
  {
    icon: CheckCircle,
    label: "Hadir Hari Ini",
    value: "111",
    subtitle: "79.29%",
    bgColor: "bg-emerald-50",
    iconBg: "bg-emerald-100",
    iconColor: "text-emerald-600",
  },
  {
    icon: Clock,
    label: "Izin",
    value: "12",
    subtitle: "8.57%",
    bgColor: "bg-amber-50",
    iconBg: "bg-amber-100",
    iconColor: "text-amber-600",
  },
  {
    icon: XCircle,
    label: "Alpha",
    value: "17",
    subtitle: "12.14%",
    bgColor: "bg-emerald-50",
    iconBg: "bg-emerald-100",
    iconColor: "text-emerald-600",
  },
]

export function StatsCards() {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
      {stats.map((stat) => (
        <Card key={stat.label} className={`${stat.bgColor} border-0 p-4`}>
          <div className="flex items-center gap-3">
            <div className={`rounded-full ${stat.iconBg} p-3`}>
              <stat.icon className={`h-6 w-6 ${stat.iconColor}`} />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
              <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.subtitle}</p>
            </div>
          </div>
        </Card>
      ))}
      
      {/* Rata-rata Kehadiran Card */}
      <Card className="bg-emerald-600 border-0 p-4 text-white">
        <div className="flex items-center gap-3">
          <div className="rounded-full bg-white/20 p-3">
            <Clock className="h-6 w-6 text-white" />
          </div>
          <div>
            <p className="text-sm text-white/80">Rata-rata Kehadiran</p>
            <p className="text-2xl font-bold">87.45%</p>
            <p className="text-xs text-white/80">Bulan Mei 2025</p>
          </div>
        </div>
      </Card>
    </div>
  )
}
