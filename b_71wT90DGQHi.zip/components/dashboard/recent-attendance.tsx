"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, ClipboardList } from "lucide-react"

const recentData = [
  { no: 1, nama: "Aurel Ramadhani", kelas: "1A", status: "Hadir", waktu: "07:12", keterangan: "-" },
  { no: 2, nama: "Fahri Ardiansyah", kelas: "1A", status: "Hadir", waktu: "07:15", keterangan: "-" },
  { no: 3, nama: "Nayla Putri", kelas: "1B", status: "Hadir", waktu: "07:16", keterangan: "-" },
  { no: 4, nama: "Rizky Maulana", kelas: "2", status: "Izin", waktu: "-", keterangan: "Sakit" },
  { no: 5, nama: "Dinda Safitri", kelas: "3", status: "Hadir", waktu: "07:20", keterangan: "-" },
  { no: 6, nama: "Ahmad Zaky", kelas: "4", status: "Hadir", waktu: "07:22", keterangan: "-" },
  { no: 7, nama: "Siti Nurhaliza", kelas: "5", status: "Alpha", waktu: "-", keterangan: "-" },
  { no: 8, nama: "M. Rafii", kelas: "6", status: "Hadir", waktu: "07:25", keterangan: "-" },
]

function StatusBadge({ status }: { status: string }) {
  const colors = {
    Hadir: "bg-emerald-100 text-emerald-700",
    Izin: "bg-amber-100 text-amber-700",
    Alpha: "bg-red-100 text-red-700",
  }
  return (
    <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${colors[status as keyof typeof colors]}`}>
      {status}
    </span>
  )
}

export function RecentAttendance() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <ClipboardList className="h-5 w-5 text-primary" />
          Presensi Terbaru
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-muted-foreground">
                <th className="pb-3 text-left font-medium">No</th>
                <th className="pb-3 text-left font-medium">Nama Siswa</th>
                <th className="pb-3 text-center font-medium">Kelas</th>
                <th className="pb-3 text-center font-medium">Status</th>
                <th className="pb-3 text-center font-medium">Waktu</th>
                <th className="pb-3 text-center font-medium">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {recentData.map((row) => (
                <tr key={row.no} className="border-b last:border-0">
                  <td className="py-2.5">{row.no}</td>
                  <td className="py-2.5 font-medium">{row.nama}</td>
                  <td className="py-2.5 text-center">{row.kelas}</td>
                  <td className="py-2.5 text-center">
                    <StatusBadge status={row.status} />
                  </td>
                  <td className="py-2.5 text-center">{row.waktu}</td>
                  <td className="py-2.5 text-center text-muted-foreground">{row.keterangan}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <button className="mt-4 flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          Lihat Semua Presensi
          <ArrowRight className="h-4 w-4" />
        </button>
      </CardContent>
    </Card>
  )
}
