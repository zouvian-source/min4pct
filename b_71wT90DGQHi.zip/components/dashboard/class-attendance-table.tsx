"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

const classData = [
  { kelas: "1A", jumlah: 23, hadir: 18, izin: 2, alpha: 3, persentase: 78.26 },
  { kelas: "1B", jumlah: 22, hadir: 17, izin: 3, alpha: 2, persentase: 77.27 },
  { kelas: "2", jumlah: 23, hadir: 19, izin: 2, alpha: 2, persentase: 82.61 },
  { kelas: "3", jumlah: 24, hadir: 20, izin: 1, alpha: 3, persentase: 83.33 },
  { kelas: "4", jumlah: 24, hadir: 19, izin: 2, alpha: 3, persentase: 79.17 },
  { kelas: "5", jumlah: 24, hadir: 20, izin: 1, alpha: 3, persentase: 83.33 },
  { kelas: "6", jumlah: 24, hadir: 18, izin: 1, alpha: 5, persentase: 75.00 },
]

function getPercentageColor(percentage: number) {
  if (percentage >= 80) return "bg-emerald-500"
  if (percentage >= 75) return "bg-amber-500"
  return "bg-red-500"
}

export function ClassAttendanceTable() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Presensi per Kelas</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-muted-foreground">
                <th className="pb-3 text-left font-medium">Kelas</th>
                <th className="pb-3 text-center font-medium">Jumlah Siswa</th>
                <th className="pb-3 text-center font-medium">Hadir</th>
                <th className="pb-3 text-center font-medium">Izin</th>
                <th className="pb-3 text-center font-medium">Alpha</th>
                <th className="pb-3 text-left font-medium">Persentase</th>
              </tr>
            </thead>
            <tbody>
              {classData.map((row) => (
                <tr key={row.kelas} className="border-b last:border-0">
                  <td className="py-3 font-medium">{row.kelas}</td>
                  <td className="py-3 text-center">{row.jumlah}</td>
                  <td className="py-3 text-center">{row.hadir}</td>
                  <td className="py-3 text-center">{row.izin}</td>
                  <td className="py-3 text-center">{row.alpha}</td>
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-16 rounded-full bg-muted">
                        <div
                          className={`h-2 rounded-full ${getPercentageColor(row.persentase)}`}
                          style={{ width: `${row.persentase}%` }}
                        />
                      </div>
                      <span className="text-xs">{row.persentase.toFixed(2)}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <button className="mt-4 flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          Lihat Detail Per Kelas
          <ArrowRight className="h-4 w-4" />
        </button>
      </CardContent>
    </Card>
  )
}
