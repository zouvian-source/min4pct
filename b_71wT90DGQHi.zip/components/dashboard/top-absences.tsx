"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"

const topAbsences = [
  { rank: 1, nama: "Ahmad Rizki", kelas: "Kelas 6", hari: 8, color: "bg-red-500" },
  { rank: 2, nama: "M. Alfian", kelas: "Kelas 5", hari: 6, color: "bg-amber-500" },
  { rank: 3, nama: "Siti Aisyah", kelas: "Kelas 4", hari: 5, color: "bg-amber-500" },
  { rank: 4, nama: "Nabila Putri", kelas: "Kelas 6", hari: 5, color: "bg-amber-500" },
  { rank: 5, nama: "Yosep Dwi", kelas: "Kelas 3", hari: 4, color: "bg-amber-500" },
]

const avatarColors = [
  "bg-blue-500",
  "bg-emerald-500",
  "bg-purple-500",
  "bg-pink-500",
  "bg-orange-500",
]

export function TopAbsences() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Siswa Alpha Terbanyak (Bulan Ini)</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {topAbsences.map((student, index) => (
            <div key={student.rank} className="flex items-center gap-3">
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-muted text-sm font-bold">
                {student.rank}
              </div>
              <div className={`flex h-10 w-10 items-center justify-center rounded-full ${avatarColors[index]} text-white font-medium`}>
                {student.nama.charAt(0)}
              </div>
              <div className="flex-1">
                <p className="font-medium">{student.nama}</p>
                <p className="text-sm text-muted-foreground">{student.kelas}</p>
              </div>
              <div className={`rounded-full ${student.color} px-2.5 py-1 text-xs font-medium text-white`}>
                {student.hari} hari
              </div>
            </div>
          ))}
        </div>

        <button className="mt-4 flex items-center gap-1 text-sm font-medium text-primary hover:underline">
          Lihat Semua
          <ArrowRight className="h-4 w-4" />
        </button>
      </CardContent>
    </Card>
  )
}
