"use client"

import { Bell, Calendar, ChevronDown, User } from "lucide-react"

export function Header() {
  return (
    <header className="flex items-center justify-between">
      <div>
        <h1 className="text-2xl font-bold text-foreground">
          Selamat Pagi, Admin 👋
        </h1>
        <p className="text-muted-foreground">
          Berikut adalah ringkasan presensi siswa hari ini.
        </p>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 rounded-lg border bg-card px-3 py-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm">Selasa, 27 Mei 2025</span>
        </div>

        <button className="relative rounded-full bg-card p-2 shadow-sm">
          <Bell className="h-5 w-5 text-muted-foreground" />
          <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-medium text-white">
            3
          </span>
        </button>

        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-500 text-white">
            <User className="h-5 w-5" />
          </div>
          <div className="text-right">
            <p className="text-sm font-medium">Admin</p>
            <p className="text-xs text-muted-foreground">Operator</p>
          </div>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
    </header>
  )
}
