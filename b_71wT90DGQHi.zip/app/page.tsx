import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { AttendanceDonut } from "@/components/dashboard/attendance-donut"
import { ClassAttendanceTable } from "@/components/dashboard/class-attendance-table"
import { MonthlyChart } from "@/components/dashboard/monthly-chart"
import { RecentAttendance } from "@/components/dashboard/recent-attendance"
import { TopAbsences } from "@/components/dashboard/top-absences"
import { Announcements } from "@/components/dashboard/announcements"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-64 min-h-screen p-6">
        <Header />

        <div className="mt-6 space-y-6">
          {/* Stats Cards */}
          <StatsCards />

          {/* First Row: Donut + Class Table + Monthly Chart */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            <div className="lg:col-span-4">
              <AttendanceDonut />
            </div>
            <div className="lg:col-span-4">
              <ClassAttendanceTable />
            </div>
            <div className="lg:col-span-4">
              <MonthlyChart />
            </div>
          </div>

          {/* Second Row: Recent Attendance + Top Absences + Announcements */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <RecentAttendance />
            </div>
            <div className="lg:col-span-3">
              <TopAbsences />
            </div>
            <div className="lg:col-span-4">
              <Announcements />
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="mt-8 flex items-center justify-between border-t pt-4 text-sm text-muted-foreground">
          <p>© 2025 MIN 4 Pacitan - Sistem Presensi Siswa</p>
          <p className="flex items-center gap-1">
            Dibuat dengan Google Apps Script & Spreadsheet
            <span className="ml-1 inline-flex h-5 w-5 items-center justify-center rounded bg-emerald-600 text-xs text-white">
              📊
            </span>
          </p>
        </footer>
      </main>
    </div>
  )
}
